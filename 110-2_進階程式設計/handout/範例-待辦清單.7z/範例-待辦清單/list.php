<?php
    //避免CORS錯誤
    header("Access-Control-Allow-Origin:*");
    $link = mysqli_connect("localhost","root","","todolist");
    if(!$link)
        die("連接資料庫失敗");
    $sql = "set NAMES UTF8";
    mysqli_query($link,$sql);
    if($_SERVER['REQUEST_METHOD']=="POST")
    {
        if(isset($_POST["type"]))
        {
            if($_POST["type"]=="select")
            {
                $sql = "select *
                          from todo";
                $result = mysqli_query($link,$sql);
                $list = mysqli_fetch_all($result,MYSQLI_ASSOC);
                echo json_encode([
                    "status" => true,
                    "code" => 201,
                    "data" => $list
                ]);
            }
            elseif($_POST["type"]=="insert")
            {
                if($_POST["todolist"]!="")
                {
                    $sql = "INSERT INTO todo
                                        (TODO_LIST,
                                         TODO_STATE)
                                 VALUES ('".$_POST["todolist"]."',
                                         '')";
                    mysqli_query($link,$sql);
                    echo json_encode([
                        "status" => true,
                        "code" => 202,
                        "message" => "新增成功"
                    ]);
                }
                else
                {
                    echo json_encode([
                        "status" => false,
                        "code" => 402,
                        "message" => "參數錯誤"
                    ]);
                }
            }
            elseif($_POST["type"]=="update")
            {
                if($_POST["todolist_no"]!="")
                {
                    $sql = "update todo
                               set TODO_STATE = 'T'
                             where TODO_NO = '".$_POST["todolist_no"]."'";
                    mysqli_query($link,$sql);
                    echo json_encode([
                        "status" => true,
                        "code" => 203,
                        "message" => "更新成功"
                    ]);
                }
                else
                {
                    echo json_encode([
                        "status" => false,
                        "code" => 403,
                        "message" => "參數錯誤"
                    ]);
                }
            }
            elseif($_POST["type"]=="delete")
            {
                if($_POST["todolist_no"]!="")
                {
                    $sql = "delete from todo
                                  where TODO_NO = '".$_POST["todolist_no"]."'";
                    mysqli_query($link,$sql);
                    echo json_encode([
                        "status" => true,
                        "code" => 204,
                        "message" => "刪除成功"
                    ]);
                }
                else
                {
                    echo json_encode([
                        "status" => false,
                        "code" => 404,
                        "message" => "參數錯誤"
                    ]);
                }
            }
            else
            {
                echo json_encode([
                    "status" => false,
                    "code" => 405,
                    "message" => "參數錯誤"
                ]);
            }
        }
        else
        {
            echo json_encode([
                "status" => false,
                "code" => 401,
                "message" => "沒有傳參數"
            ]);
        }
    }
    else
    {
        echo json_encode([
            "status" => false,
            "code" => 400,
            "message" => "方法錯誤"
        ]);
    }
?>